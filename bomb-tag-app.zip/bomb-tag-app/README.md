# 폭탄 돌리기 (안드로이드 앱)

## 빌드 방법
1. GitHub에 새 저장소를 만들고 이 폴더의 내용을 그대로 올립니다. 숨김 폴더인 `.github`도 함께 올려야 합니다.
2. 저장소의 **Actions** 탭에서 "Build APK"가 끝날 때까지 기다립니다(5~8분).
3. 완료된 실행을 열고 **Artifacts**에서 `bomb-tag-apk`를 내려받아 압축을 풀면 `app-debug.apk`가 나옵니다.

## 바꿀 수 있는 것
- 앱 아이콘과 시작 화면: `assets` 폴더의 그림(icon-only, icon-foreground, icon-background, splash). 같은 이름으로 바꿔 넣으면 다음 빌드에 반영됩니다.
- 게임 내용: `www/index.html`
- 앱 이름과 ID: `capacitor.config.json`의 `appName`과 `appId`. 다른 앱과 ID가 겹치면 설치할 때 그 앱을 덮어씁니다.
- 화면 방향: `.github/workflows/build-apk.yml`의 `sensorLandscape`. 지우면 세로 화면도 허용됩니다.
